import React from 'react'
import './Help.css'
import ImgAsset from '../public'
import {Link} from 'react-router-dom'
export default function Help () {
	return (
		<div className='Help_Help'>
			<img className='image2' src = {ImgAsset.Home_image2} />
			<div className='Heder'>
				<div className='navigation'>
					<div className='Logo0'>
						<div className='Ellipse4'/>
						<img className='image3' src = {ImgAsset.Help_image3} />
					</div>
					<div className='Menu'>
						<Link to='/home'>
							<span className='Home'>Home</span>
						</Link>
						<Link to='/storage'>
							<span className='Storage'>Storage</span>
						</Link>
						<span className='Help_1'>Help</span>
						<Link to='/aboutus'>
							<span className='AboutUs'>About Us</span>
						</Link>
					</div>
					<div className='LogandSignin'>
						<Link to='/signup'>
							<div className='Signup'>
								<div className='Rectangle1'/>
								<span className='SignUp'>Sign Up</span>
							</div>
						</Link>
						<Link to='/login'>
							<div className='Login'>
								<div className='Rectangle1_1'/>
								<span className='LogIn'>Log In</span>
							</div>
						</Link>
					</div>
				</div>
			</div>
			<div className='_'>
				<span className='_2024UkraineLvivAllrightsreserved'>2024 Ukraine, Lviv. All rights reserved</span>
				<div className='Contus'>
					<span className='Contactus'>Contact us</span>
					<div className='socialfooter'>
						<img className='image4' src = {ImgAsset.Home_image4} />
						<img className='image5' src = {ImgAsset.Home_image5} />
						<img className='image6' src = {ImgAsset.Home_image6} />
						<img className='image7' src = {ImgAsset.Home_image7} />
					</div>
				</div>
			</div>
		</div>
	)
}