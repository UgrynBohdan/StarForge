import React from 'react'
import {Link} from 'react-router-dom'
export default function HomePage () {
    return (
	<div>
		<Link to='/Home'><div>Home</div></Link>
		<Link to='/SignUp'><div>SignUp</div></Link>
		<Link to='/LogIn'><div>LogIn</div></Link>
		<Link to='/Help'><div>Help</div></Link>
		<Link to='/AboutUs'><div>AboutUs</div></Link>
		<Link to='/Storage'><div>Storage</div></Link>
	</div>
	)
}