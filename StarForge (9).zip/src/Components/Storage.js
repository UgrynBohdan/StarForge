import React from 'react'
import './Storage.css'
import ImgAsset from '../public'
import {Link} from 'react-router-dom'
export default function Storage () {
	return (
		<div className='Storage_Storage'>
			<img className='image2' src = {ImgAsset.Home_image2} />
			<div className='Heder'>
				<div className='navigation'>
					<div className='Logo0'>
						<div className='Ellipse4'/>
						<img className='image3' src = {ImgAsset.Help_image3} />
					</div>
					<div className='Menu'>
						<Link to='/home'>
							<span className='Home'>Home</span>
						</Link>
						<span className='Storage_1'>Storage</span>
						<Link to='/help'>
							<span className='Help'>Help</span>
						</Link>
						<Link to='/aboutus'>
							<span className='AboutUs'>About Us</span>
						</Link>
					</div>
				</div>
				<div className='LogIn'>
					<div className='Rectangle1'/>
					<span className='Emailgmailcom'>Email@gmail.com</span>
				</div>
			</div>
			<div className='Window'>
				<div className='Rectangle5'/>
				<img className='Line1' src = {ImgAsset.Storage_Line1} />
				<div className='Description'>
					<span className='Name'>Name</span>
					<span className='Changedate'>Change date</span>
					<span className='Type'>Type</span>
					<span className='Size'>Size</span>
				</div>
				<div className='Files'>
					<div className='catpng'>
						<div className='Rectangle6'/>
						<div className='pngsvgrepocom1'>
							<img className='Vector' src = {ImgAsset.Storage_Vector} />
							<div className='Group'>
								<img className='Vector_1' src = {ImgAsset.Storage_Vector_1} />
								<img className='Vector_2' src = {ImgAsset.Storage_Vector_2} />
							</div>
							<div className='Group_1'>
								<img className='Vector_3' src = {ImgAsset.Storage_Vector_3} />
								<img className='Vector_4' src = {ImgAsset.Storage_Vector_4} />
								<img className='Vector_5' src = {ImgAsset.Storage_Vector_5} />
								<img className='Vector_6' src = {ImgAsset.Storage_Vector_6} />
							</div>
						</div>
						<span className='_110320241112'>11.03.2024 11:12 </span>
						<span className='png'>png</span>
						<span className='_65KB'>65 KB</span>
						<span className='catpng_1'>cat.png</span>
					</div>
					<div className='catxlsx'>
						<div className='Rectangle6_1'/>
						<div className='excelsvgrepocom1'>
							<img className='Vector_7' src = {ImgAsset.Storage_Vector_7} />
							<div className='Group_2'>
								<img className='Vector_8' src = {ImgAsset.Storage_Vector_8} />
								<img className='Vector_9' src = {ImgAsset.Storage_Vector_9} />
							</div>
							<div className='Group_3'>
								<img className='Vector_10' src = {ImgAsset.Storage_Vector_10} />
								<img className='Vector_11' src = {ImgAsset.Storage_Vector_11} />
								<img className='Vector_12' src = {ImgAsset.Storage_Vector_12} />
								<img className='Vector_13' src = {ImgAsset.Storage_Vector_13} />
								<img className='Vector_14' src = {ImgAsset.Storage_Vector_14} />
							</div>
						</div>
						<span className='_120320241311'>12.03.2024 13:11 </span>
						<span className='xlsx'>xlsx</span>
						<span className='_112KB'>112 KB</span>
						<span className='catxlsx_1'>cat.xlsx</span>
					</div>
					<div className='catdocx'>
						<div className='Rectangle6_2'/>
						<div className='wordsvgrepocom1'>
							<img className='Vector_15' src = {ImgAsset.Storage_Vector_15} />
							<div className='Group_4'>
								<img className='Vector_16' src = {ImgAsset.Storage_Vector_16} />
								<img className='Vector_17' src = {ImgAsset.Storage_Vector_17} />
							</div>
							<div className='Group_5'>
								<img className='Vector_18' src = {ImgAsset.Storage_Vector_18} />
								<img className='Vector_19' src = {ImgAsset.Storage_Vector_19} />
								<img className='Vector_20' src = {ImgAsset.Storage_Vector_20} />
								<img className='Vector_21' src = {ImgAsset.Storage_Vector_21} />
							</div>
						</div>
						<span className='_130220241522'>13.02.2024 15:22 </span>
						<span className='docx'>docx</span>
						<span className='_512KB'>512 KB</span>
						<span className='catdocx_1'>cat.docx</span>
					</div>
					<div className='catpdf'>
						<div className='Rectangle6_3'/>
						<div className='pdfsvgrepocom1'>
							<img className='Vector_22' src = {ImgAsset.Storage_Vector_22} />
							<div className='Group_6'>
								<img className='Vector_23' src = {ImgAsset.Storage_Vector_23} />
								<img className='Vector_24' src = {ImgAsset.Storage_Vector_24} />
							</div>
							<div className='Group_7'>
								<img className='Vector_25' src = {ImgAsset.Storage_Vector_25} />
								<img className='Vector_26' src = {ImgAsset.Storage_Vector_26} />
								<img className='Vector_27' src = {ImgAsset.Storage_Vector_27} />
								<img className='Vector_28' src = {ImgAsset.Storage_Vector_28} />
							</div>
						</div>
						<span className='_230220242256'>23.02.2024 22:56 </span>
						<span className='pdf'>pdf</span>
						<span className='_132KB'>132 KB</span>
						<span className='catpdf_1'>cat.pdf</span>
					</div>
				</div>
			</div>
			<span className='MyFiles'>My Files</span>
			<div className='_'>
				<span className='_2024UkraineLvivAllrightsreserved'>2024 Ukraine, Lviv. All rights reserved</span>
				<div className='Contus'>
					<span className='Contactus'>Contact us</span>
					<div className='socialfooter'>
						<img className='image4' src = {ImgAsset.Home_image4} />
						<img className='image5' src = {ImgAsset.Home_image5} />
						<img className='image6' src = {ImgAsset.Home_image6} />
						<img className='image7' src = {ImgAsset.Home_image7} />
					</div>
				</div>
			</div>
		</div>
	)
}