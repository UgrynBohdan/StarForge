import React from 'react'
import './SignUp.css'
import ImgAsset from '../public'
import {Link} from 'react-router-dom'
export default function SignUp () {
	return (
		<div className='SignUp_SignUp'>
			<img className='image2' src = {ImgAsset.Home_image2} />
			<div className='FieldofSignUp'>
				<div className='Field'/>
				<span className='CreateAccount'>Create Account</span>
				<Link to='/storage'>
					<div className='Calltoaction'>
						<div className='Rectangle2'/>
						<span className='SignUp_1'>Sign Up</span>
					</div>
				</Link>
				<div className='Email'>
					<span className='Email_1'>Email</span>
					<div className='fieldem'>
						<div className='Rectangle4'/>
						<span className='email'>email</span>
					</div>
				</div>
				<div className='Name'>
					<span className='Name_1'>Name</span>
					<div className='fieldname'>
						<div className='Rectangle4_1'/>
						<span className='name'>name</span>
					</div>
				</div>
				<div className='Logo0'><div className='Ellipse4' style={{backgroundImage: `url(${ImgAsset.Help_image3})`}}/>
					<img className='image3' src = {ImgAsset.Help_image3} />
				</div>
			</div>
			<div className='_'>
				<span className='_2024UkraineLvivAllrightsreserved'>2024 Ukraine, Lviv. All rights reserved</span>
				<div className='Contus'>
					<span className='Contactus'>Contact us</span>
					<div className='socialfooter'>
						<img className='image4' src = {ImgAsset.Home_image4} />
						<img className='image5' src = {ImgAsset.Home_image5} />
						<img className='image6' src = {ImgAsset.Home_image6} />
						<img className='image7' src = {ImgAsset.Home_image7} />
					</div>
				</div>
			</div>
		</div>
	)
}